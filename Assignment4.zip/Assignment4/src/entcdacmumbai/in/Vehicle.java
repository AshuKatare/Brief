package entcdacmumbai.in;
public class Vehicle {
    
   
    public void drive() {
        System.out.println("Tesla");
    }

    public void drive(int speed) {
        System.out.println("Tesla goes at  " + speed + " km/h.");
    }

    
    public void drive(int speed, String direction) {
        System.out.println("Tesla goes at " + speed + " km/h in the " + direction + " direction.");
    }
    
    public void drive(int speed, String direction, String raipur) {
        System.out.println("Tesla goes at" + speed + " km/h in the " + direction + " direction in " + raipur + " city.");
    }

    public static void main(String[] args) {
        Vehicle car = new Vehicle();

        car.drive(); 
        car.drive(60); 
        car.drive(80, "north"); 
        car.drive(100, "west", "Raipur"); 
    }
}


package entcdacmumbai.in;

import java.util.Scanner;

class Student{
	private String name;
	private int standard;
	private float rollno;
	 
	void acceptRecord () {
		Scanner sc = new Scanner (System.in);
		System.out.print("Name : ");
		this.name = sc.nextLine();
		System.out.print("Standard : ");
		this.standard = sc.nextInt();
		System.out.print("Rollno : ");
		this.rollno = sc.nextFloat();
		sc.close();
	}
	void printRecord () {
		System.out.printf("%-20s%-10d%-10.2f", this.name, this.standard, this.rollno);
	}
}

public class Program{
	public static void main(String[] args) {
		Student std = new Student();
		std.acceptRecord();
		std.printRecord();
	}
}
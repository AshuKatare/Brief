package entcdacmumbai.in;

public class Employee {
    
    public void details(String name) {
        System.out.println("Name        : " + name);
    }

    public void details(long id) {
        System.out.println("Employee id : " + id);
    }

    public void drive(float contactno, double salary) {
        System.out.println("Contact No  : " + contactno + ", Salary: " + salary);
    }
    
    public static void main(String[] args) {
        Employee emp = new Employee();

        emp.details("Elon Musk"); 
        emp.details(5254454L); // Use a long literal for larger ID values
        emp.drive(98789789988f, 80000); // Adjust or remove arguments accordingly
    }
}

